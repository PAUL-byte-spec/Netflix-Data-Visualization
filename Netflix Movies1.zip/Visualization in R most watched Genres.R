# Diagram showing the most watched Genres
ggplot(Netflix_cleaned_dataset, aes(x = rating)) +
  geom_bar() +
  coord_flip() +
  scale_x_discrete(limits = rev(levels(Netflix_cleaned_dataset$rating))) +
  labs(title = "Most Watched Genres", x = "duration", y = "rating")
